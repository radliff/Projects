Name: Radliff Jeantinor 
Section: 11949 
UFL Email: r.jeantinor@ufl.edu 
System: Windows 
Compiler: g++  
SFML Version: 2.5.1  
IDE: CLion  
Other notes: I also have an M1 Macbook Pro that this compiled on as well. I used clang 
and Clion for the Macbook, and everything worked. 